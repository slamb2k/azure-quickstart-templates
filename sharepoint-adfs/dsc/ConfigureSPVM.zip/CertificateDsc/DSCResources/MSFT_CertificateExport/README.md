# Description

The resource is used to export a certificate from a Windows certificate
store.
